# Bagelshoes-A21Bookcase
Bagelshoes - Alpha 21 Bookcase

=========================================Features==========================

A21 Bookcase simply expands the inventory of the already buildable in game bookcase to 7 columns across and 10 rows down. This allows book collections to be stored very neatly.

===========================================================================

Mod Installation

Download and unpack ("extract here") the Zip file.

Place the extracted folder into your game's "Mods" folder.

===========================================================================
