# Bagelshoes-ToolsPlus
Bagelshoes - Tools Plus

Tools Plus is a mod for 7 Days to Die by Bagelshoes that allows additional tools to be used at various workstations.

It is a server side mod that does not require a client download to function.

=====================================================================

Mod Installation

1. Download and unpack ("extract here") the Zip file.

2. Place the extracted folder into your game's "Mods" folder.

=====================================================================
